import numpy as np
import pandas as pd
from pandas.core.frame import DataFrame

def backtest(data, num):
    #num为选取的股票数量
    #输入的data必须为numpy的ndarray格式，或者pandas的DataFrame格式
    #m每一列分别为代码、日期、真实值、预测值

    df = None
    if isinstance(data, np.ndarray):
        df = pd.DataFrame(data, columns=['code', 'date', 'true_y', 'pre_y'])
    elif isinstance(data, DataFrame):
        df = data.copy()[['code', 'date', 'true_y', 'pre_y']]

    dates = np.unique(df['date']) #获取日期列表
    index = 0
    model_days = 2  # 两天模型
    tax_and_fee = 0.0014 #手续费
    value = [1 / model_days for i in range(model_days)]  # 两天模型的话，每一个交易组合的净值占比是1/2
    pick_code = np.empty((len(dates), num))

    arr = []
    for date in dates:
        day_df = df[df.date == date]  # 选取出date当天的预测结果

        day_df = day_df.sort_values(by=['pre_y'], ascending=False).reset_index(drop=True)  # 根据预测结果从高到低进行排序
        day_df = day_df[0:num]# 选取需要的数量

        mean_y = day_df['true_y'].mean()  # 选取的股票的平均涨跌幅
        up_rate = day_df[day_df.true_y > 0].shape[0] / day_df.shape[0]  # 上涨占比 = 选中的股票中，上涨的个数/总数
        profit = mean_y - tax_and_fee  # 收益 = 涨跌幅-手续费
        value[index % model_days] = value[index % model_days] * (1 + profit)  # 这个组合的净值变为原净值*（1+收益）
        value_sum = sum(value)  # 累计净值

        mean_y_top10 = 0
        mean_y_11_20 = 0
        mean_y_after_20 = 0
        # 如果选取数量超过20只的话，做有效性检查
        if num > 20:
            mean_y_top10 = day_df[0:10]['true_y'].mean()  # 前10只的平均涨跌幅
            mean_y_11_20 = day_df[10:20]['true_y'].mean()  # 11-20只的平均涨跌幅
            mean_y_after_20 = day_df[20:]['true_y'].mean()  # 20只后的平均涨跌幅
        arr.append([date, profit, value_sum, up_rate, mean_y_top10, mean_y_11_20, mean_y_after_20])

        pick_code[index] = day_df['code']
        index += 1

    result = pd.DataFrame(arr, columns=['date', 'daily_profit', 'value_sum', 'up_rate', 'mean_y_top10', 'mean_y_11_20',
                                        'mean_y_after_20']) #日期、当日收益、累计净值、上涨比例、前10只涨幅、11-20涨幅、20之后的涨幅

    ##开始计算最大回撤
    value_sum_arr = [1] + result['value_sum'].values.tolist()  # 最前面加初始净值1
    max_retracement = 0  # 初始化最大回撤
    for i in range(1, len(value_sum_arr)):
        retracement = value_sum_arr[i] / max(value_sum_arr[:i]) - 1 #当前净值/之前的最大净值-1
        if retracement < max_retracement: #小于所记录的最大回撤值，则赋值。max_retracement与retracement都为负数
            max_retracement = retracement
    return result, max_retracement, pick_code #返回 日期、当日收益、累计净值、上涨比即可例、前10只涨幅、11-20涨幅、20之后的涨幅的列表，以及最大回撤数据

    #注意：如需要其他自定义的回测数据，则自行实现后，与result进行组合拼装