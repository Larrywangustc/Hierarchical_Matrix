import numpy as np
import math
_protected_ratio = 0.00000001

# 除法，加分母为0处理方式
def protected_division(x1, x2):
    """Closure of division (x1/x2) for zero denominator."""
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.where(np.abs(x2) > _protected_ratio, np.divide(x1, x2), 1.)

def protected_sqrt(x1):
    """Closure of square root for negative arguments."""
    return np.sqrt(np.abs(x1))

def protected_log(x1):
    """Closure of log for zero arguments."""
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.where(np.abs(x1) > _protected_ratio, np.log(np.abs(x1)), 0.)

def delay(data, period):
    value = data.shift(period)
    return value

def delta(data, day):
    value = data - data.shift(day)
    return value

def ts_stddev(data, window):
    value = data.rolling(window).std(ddof=0).tolist()
    return value

def ts_vardev(data, window):
    value = np.array(data.rolling(window).var(ddof=0).tolist())
    return value

def ts_ma(data, window):
    value = data.rolling(window).mean()
    return value

def ts_sum(data, window):
    value = data.rolling(window).sum()
    return value

def ts_min(data, window):
    value = data.rolling(window).min()
    return value

def ts_max(data, window):
    value = data.rolling(window).max()
    return value

def ts_argmax(data, window):
    value = data.rolling(window).apply(lambda x: np.argmax(x) + 1) / window
    return value

def ts_argmin(data, window):
    value = data.rolling(window).apply(lambda x: np.argmin(x) + 1) / window
    return value

def correlation(x, y):
    value = x.corr(y)
    return value

def rate(x, y, l):
    value = (-x.shift(-1) + y.shift(-l-1))/x.shift(-1)
    return value

def next_day_limitstatus(x, y):
    value = (x.shift(-1)-y)/y
    return value

def last_day_limit(pre_close, open):
    # 判断样本最后一天是否一字板涨停
    if (open - pre_close)/pre_close >= 0.098:
        return 1
    else:
        return 0

def rate_of_flow(dq_mv, mv):
    return dq_mv/mv

def ts_2length(data, window):
    value = data.rolling(window).apply(lambda x: np.sqrt((x ** 2).sum()))
    return value
