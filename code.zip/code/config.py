version = "wzy_0.1.0"
model_name = "lstmw"

rawdata_dir = '/cgrdata/wzyu/'
code_dir = '/cgrdata/wzyu/%s/' % version
data_dir = '%s%s' % (rawdata_dir, 'data/wd_data/')
raw_dir = '%s%s' % (rawdata_dir, 'data/wd_data/')

newdata_dir = '%s%s' % (code_dir, 'train/newdata/')
model_save_dir = '%s%s' % (code_dir, 'train/modelsave/')
model_result_dir = '%s%s' % (code_dir, 'train/result/')
result_save_dir = '%s%s' % (code_dir, 'train/result/result.csv')
pre_save_dir = '%s%s' % (code_dir, 'predict/result/pre.csv')
pickcode_save_dir = '%s%s' % (code_dir, 'train/result/pick_code.csv')
predata_save_dir = '%s%s' % (code_dir, 'train/result/predata.csv')
allpredata_save_dir = '%s%s' % (code_dir, 'predict/result/allpredata.csv')

pre_result_dir = '%s%s' % (code_dir, 'predict/result/')

create_process_count = 10

train_start_date = 20170101
train_end_date = 20200901
testdate = 20200101

pre_start_date = 20200601
pre_end_date = 20200731
pre_date = 20200731

x_train_path = '%s%s%s%s' % (code_dir, 'train/newdata/', version, '_d2_xtrain.npy')
y_train_path = '%s%s%s%s' % (code_dir, 'train/newdata/', version, '_d2_ytrain.npy')

x_predict_path = '%s%s%s%s' % (code_dir, 'train/newdata/', version, '_d2_xpredict.npy')
y_predict_path = '%s%s%s%s' % (code_dir, 'train/newdata/', version, '_d2_ypredict.npy')
# 标签的标题
label_columes = ['code', 'date', 'y']

timesteps = 10

d = 0.1
i = 1
neurons = [256, 128, 16, 1]
#neurons = [128, 64, 16, 1]
epochs = 100


save_path = '%s%s_%s.h5' % (model_save_dir, version, model_name)
json_save_path = '%s%s%s_%s.json' % (model_save_dir, 'json/', version, model_name)
weights_save_path = '%s%s%s_%s.json' % (model_save_dir, 'weights/', version, model_name)

model1_save_dir = '%s%s' % (code_dir, 'predict/modelsave/')
json1_save_path = '%s%s%s_%s.json' % (model1_save_dir, 'json/', version, model_name)
weights1_save_path = '%s%s%s_%s.json' % (model1_save_dir, 'weights/', version, model_name)

raw_min_dir = '%s%s' % (rawdata_dir, 'data/ths_data/')
