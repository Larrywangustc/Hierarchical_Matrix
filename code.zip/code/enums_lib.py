from enum import Enum

class DataType(Enum):
    Day = 'Day'
    Label = 'Label'
    M30 = 'M30'
    H1 = 'Hour1'
    H2 = 'Hour2'
